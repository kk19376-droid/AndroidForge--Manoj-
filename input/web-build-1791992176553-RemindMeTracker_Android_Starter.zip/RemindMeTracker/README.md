# RemindMe Tracker — Android Starter

This ZIP contains a starter Android Studio project using Kotlin and Jetpack Compose.

## Included
- Dark Material 3 UI
- Dashboard shell with Today, Calendar, Habits, Trackers, and Reports destinations
- In-memory reminder list
- Add-reminder dialog and completion checkboxes

## Important limitations
This is **not a complete production app or installable APK**. Reminders currently exist only in app memory and do not trigger Android alarms or notifications. The Calendar, Habits, Trackers, Reports, database, sync, encryption, authentication, and full-screen alarm workflows are placeholders for subsequent implementation.

## Build
1. Extract the ZIP.
2. Open the `RemindMeTracker` folder in Android Studio.
3. Allow Gradle sync to finish.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. The debug APK is normally created at `app/build/outputs/apk/debug/app-debug.apk`.

Use a current Android Studio installation with JDK 17. Gradle may need internet access to download dependencies. Before publishing, implement persistence, alarm scheduling, permission handling, security, and tests.

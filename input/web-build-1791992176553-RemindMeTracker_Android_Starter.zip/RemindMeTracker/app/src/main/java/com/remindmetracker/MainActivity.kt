package com.remindmetracker

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.UUID

data class ReminderItem(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val details: String,
    val time: String,
    val done: Boolean = false
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { RemindMeApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RemindMeApp() {
    var reminders by remember { mutableStateOf(listOf(
        ReminderItem(title = "Exercise", details = "Daily movement", time = "7:00 PM"),
        ReminderItem(title = "Read for 20 minutes", details = "Personal habit", time = "9:00 PM")
    )) }
    var showDialog by remember { mutableStateOf(false) }
    var title by remember { mutableStateOf("") }
    var details by remember { mutableStateOf("") }
    var time by remember { mutableStateOf("7:00 PM") }
    var selectedTab by remember { mutableStateOf(0) }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = androidx.compose.ui.graphics.Color(0xFF8DD5B7),
            secondary = androidx.compose.ui.graphics.Color(0xFFB8C9FF),
            background = androidx.compose.ui.graphics.Color(0xFF101512),
            surface = androidx.compose.ui.graphics.Color(0xFF171E1A)
        )
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("RemindMe Tracker", fontWeight = FontWeight.Bold)
                            Text("Your day, made clearer", style = MaterialTheme.typography.labelMedium)
                        }
                    },
                    actions = {
                        IconButton(onClick = { showDialog = true }) {
                            Icon(Icons.Default.Add, contentDescription = "Add reminder")
                        }
                    }
                )
            },
            floatingActionButton = {
                ExtendedFloatingActionButton(
                    onClick = { showDialog = true },
                    icon = { Icon(Icons.Default.Add, contentDescription = null) },
                    text = { Text("Add reminder") }
                )
            },
            bottomBar = {
                NavigationBar {
                    listOf("Today", "Calendar", "Habits", "Trackers", "Reports").forEachIndexed { index, label ->
                        NavigationBarItem(
                            selected = selectedTab == index,
                            onClick = { selectedTab = index },
                            icon = {
                                Icon(
                                    if (index == 0) Icons.Default.Notifications else Icons.Default.CheckCircle,
                                    contentDescription = label
                                )
                            },
                            label = { Text(label) }
                        )
                    }
                }
            }
        ) { padding ->
            Column(
                modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Spacer(Modifier.height(4.dp))
                Text(
                    when (selectedTab) {
                        0 -> "Today's overview"
                        1 -> "Calendar"
                        2 -> "Habits"
                        3 -> "Personal trackers"
                        else -> "Reports"
                    },
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold
                )
                if (selectedTab == 0) {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        SummaryCard("Reminders", "${reminders.count { !it.done }} left", Modifier.weight(1f))
                        SummaryCard("Completed", "${reminders.count { it.done }}", Modifier.weight(1f))
                    }
                    Text("Upcoming reminders", style = MaterialTheme.typography.titleMedium)
                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        contentPadding = PaddingValues(bottom = 90.dp)
                    ) {
                        items(reminders, key = { it.id }) { item ->
                            Card(shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(16.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(Modifier.weight(1f)) {
                                        Text(item.title, style = MaterialTheme.typography.titleMedium)
                                        if (item.details.isNotBlank()) {
                                            Text(item.details, style = MaterialTheme.typography.bodyMedium,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        }
                                        Spacer(Modifier.height(4.dp))
                                        Text(item.time, style = MaterialTheme.typography.labelMedium,
                                            color = MaterialTheme.colorScheme.primary)
                                    }
                                    Checkbox(
                                        checked = item.done,
                                        onCheckedChange = { checked ->
                                            reminders = reminders.map {
                                                if (it.id == item.id) it.copy(done = checked) else it
                                            }
                                        }
                                    )
                                }
                            }
                        }
                    }
                } else {
                    Card(shape = RoundedCornerShape(18.dp)) {
                        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(
                                when (selectedTab) {
                                    1 -> "Calendar views are planned for the next build."
                                    2 -> "Create habits and track streaks in the full version."
                                    3 -> "Build custom trackers for water, weight, sleep, and more."
                                    else -> "Your completion trends and reports will appear here."
                                },
                                style = MaterialTheme.typography.bodyLarge
                            )
                            Text("This starter build currently demonstrates the app shell and reminder list.",
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }

        if (showDialog) {
            AlertDialog(
                onDismissRequest = { showDialog = false },
                title = { Text("New reminder") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(value = title, onValueChange = { title = it },
                            label = { Text("Title") }, singleLine = true)
                        OutlinedTextField(value = details, onValueChange = { details = it },
                            label = { Text("Description") })
                        OutlinedTextField(value = time, onValueChange = { time = it },
                            label = { Text("Time (e.g. 7:00 PM)") }, singleLine = true)
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        if (title.isNotBlank()) {
                            reminders = reminders + ReminderItem(
                                title = title.trim(), details = details.trim(), time = time.trim()
                            )
                            title = ""; details = ""; time = "7:00 PM"
                            showDialog = false
                        }
                    }) { Text("Add") }
                },
                dismissButton = {
                    TextButton(onClick = { showDialog = false }) { Text("Cancel") }
                }
            )
        }
    }
}

@Composable
private fun SummaryCard(title: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier = modifier, shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text(title, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        }
    }
}

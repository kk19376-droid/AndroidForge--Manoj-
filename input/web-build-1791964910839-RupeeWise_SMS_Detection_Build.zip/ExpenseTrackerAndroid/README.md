# RupeeWise Android project (combined update)

This project contains the combined RupeeWise prototype: dark theme, transaction history and budgets, SMS review inbox with editable category/amount/date/payment method, people management, equal/unequal/percentage split calculator, credit-card balances and repayment entries, loan balances and repayment entries, and custom trackers/categories. Data is stored locally in WebView localStorage.

## Build using AndroidForge from an Android phone
1. Back up/export JSON from the currently installed RupeeWise first.
2. Upload this complete `ExpenseTrackerAndroid` project to your AndroidForge repository/build workflow. Keep `applicationId` `com.example.rupeewise` and the same signing key as your installed APK if you want Android to install it as an update.
3. Run the AndroidForge build workflow and download the APK artifact to your phone.
4. Install only if the signature/package matches. If Android reports a signature conflict, do not uninstall the old app until you have exported and verified a backup.
5. Open RupeeWise and choose Review → Import older SMS messages. Grant SMS permission only if you want SMS import. Check every result; detections remain pending until you approve them.

## SMS privacy / policy / limitations
- SMS inbox import runs locally on the device after the user taps the import button and grants permission. It scans up to the latest 5,000 inbox messages. The parser is heuristic and can miss transactions or misread message formats; review each entry before approval.
- This edition includes both inbox import (`READ_SMS`) and incoming-message detection (`RECEIVE_SMS`). The Review inbox asks for an in-app disclosure confirmation before starting the Android permission flow. Android runtime permission is still required. Every detected transaction stays pending for the user to inspect and approve.
- Google Play lists SMS-based money management (including budget tracking) as a possible exception use case, subject to review. Approval is not automatic: if publishing on Google Play, complete the SMS/Call Log Permissions Declaration Form, provide a privacy policy and prominent disclosure/consent, and wait for Google Play review. Do not claim approval before it is granted. See https://support.google.com/googleplay/android-developer/answer/10208820.
- Play Protect can still block a sideloaded APK for reasons unrelated to Play policy. This project does not bypass Play Protect or conceal its permissions.
- Before real-world use, test with non-sensitive/sample messages and verify your backup/restore. No SMS data is sent to a server by this code.

## Important
This is source code, not a prebuilt signed APK. Build/signing must be done by AndroidForge. Updating an installed app requires the same application ID and signing certificate. LocalStorage data may not survive uninstalling, clearing app data, changing WebView storage behavior, or changing app identity; export a backup first.


## R-letter app icon / separate install
This variant uses a custom RupeeWise R launcher icon and applicationId `com.example.rupeewise.rletter` so it can be installed as a separate app alongside an existing `com.example.rupeewise` installation. Because it is a separate package, it will not automatically inherit the old app's local data. Export/import a JSON backup to transfer data if the app supports it.
